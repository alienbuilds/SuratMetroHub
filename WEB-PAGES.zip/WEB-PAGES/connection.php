<?php

$conn=mysqli_connect('localhost','pranav','123','metroDb');

if(!$conn)
{
    echo "Connection To Database Not Established";
}

?>